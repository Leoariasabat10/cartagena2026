import { TripCard } from "@/components/trip-card"

export default function Page() {
  // Fija una fecha objetivo a 45 días desde el primer render del servidor.
  const targetDate = Date.now() + 45 * 24 * 60 * 60 * 1000

  return (
    <main className="flex min-h-dvh items-center justify-center bg-background p-4">
      <TripCard
        destination="Tulum 2026"
        date="Del 14 al 21 de marzo"
        targetDate={targetDate}
        travelers={6}
      />
    </main>
  )
}
