import { MapPin, Plane, Users } from "lucide-react"
import { Countdown } from "@/components/countdown"

type TripCardProps = {
  destination: string
  date: string
  targetDate: number
  travelers: number
}

export function TripCard({
  destination,
  date,
  targetDate,
  travelers,
}: TripCardProps) {
  return (
    <div className="border-neon-pink animate-neon-pulse relative w-full max-w-md overflow-hidden rounded-3xl border bg-card/60 p-6 backdrop-blur-sm sm:p-8">
      {/* Glow accent */}
      <div
        aria-hidden
        className="pointer-events-none absolute -right-16 -top-16 h-40 w-40 rounded-full bg-[oklch(0.78_0.2_350)] opacity-20 blur-3xl"
      />
      <div
        aria-hidden
        className="pointer-events-none absolute -bottom-16 -left-16 h-40 w-40 rounded-full bg-[oklch(0.85_0.18_195)] opacity-20 blur-3xl"
      />

      <header className="relative flex items-center justify-between">
        <span className="flex items-center gap-2 text-xs uppercase tracking-[0.2em] text-muted-foreground">
          <Plane className="h-4 w-4 text-neon-cyan" />
          Próxima escapada
        </span>
        <span className="flex items-center gap-1.5 rounded-full border border-border px-3 py-1 text-xs text-muted-foreground">
          <Users className="h-3.5 w-3.5" />
          {travelers}
        </span>
      </header>

      <div className="relative mt-6">
        <h1 className="text-neon-pink text-balance font-mono text-4xl font-bold leading-tight sm:text-5xl">
          {destination}
        </h1>
        <p className="mt-2 flex items-center gap-1.5 text-sm text-muted-foreground">
          <MapPin className="h-4 w-4" />
          {date}
        </p>
      </div>

      <div className="relative mt-8">
        <p className="mb-3 text-center text-xs uppercase tracking-[0.3em] text-muted-foreground">
          Cuenta regresiva
        </p>
        <Countdown target={targetDate} />
      </div>

      <p className="relative mt-6 text-center text-sm text-neon-cyan">
        ¡Prepara las maletas! 🧳
      </p>
    </div>
  )
}
